/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author tharu
 */
public class Profile {
    
    private String name;
    private String Geographic_data;
    private String Date_of_birth;
    private String Telephone_numbers;

    public String getTelephone_numbers() {
        return Telephone_numbers;
    }

    public void setTelephone_numbers(String Telephone_numbers) {
        this.Telephone_numbers = Telephone_numbers;
    }
    private String FAX_numbers;
    private String Email_Address;
    private String Social_Security_number;
    private String Medical_record_number;
    private String Health_plan_beneficiary_number;
    private String Bank_account_numbers;
    private String Cerificate_license_number;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGeographic_data() {
        return Geographic_data;
    }

    public void setGeographic_data(String Geographic_data) {
        this.Geographic_data = Geographic_data;
    }

    public String getDate_of_birth() {
        return Date_of_birth;
    }

    public void setDate_of_birth(String Date_of_birth) {
        this.Date_of_birth = Date_of_birth;
    }

    public String getFAX_numbers() {
        return FAX_numbers;
    }

    public void setFAX_numbers(String FAX_numbers) {
        this.FAX_numbers = FAX_numbers;
    }

    public String getEmail_Address() {
        return Email_Address;
    }

    public void setEmail_Address(String Email_Address) {
        this.Email_Address = Email_Address;
    }

    public String getSocial_Security_number() {
        return Social_Security_number;
    }

    public void setSocial_Security_number(String Social_Security_number) {
        this.Social_Security_number = Social_Security_number;
    }

    public String getMedical_record_number() {
        return Medical_record_number;
    }

    public void setMedical_record_number(String Medical_record_number) {
        this.Medical_record_number = Medical_record_number;
    }

    public String getHealth_plan_beneficiary_number() {
        return Health_plan_beneficiary_number;
    }

    public void setHealth_plan_beneficiary_number(String Health_plan_beneficiary_number) {
        this.Health_plan_beneficiary_number = Health_plan_beneficiary_number;
    }

    public String getBank_account_numbers() {
        return Bank_account_numbers;
    }

    public void setBank_account_numbers(String Bank_account_numbers) {
        this.Bank_account_numbers = Bank_account_numbers;
    }

    public String getCerificate_license_number() {
        return Cerificate_license_number;
    }

    public void setCerificate_license_number(String Cerificate_license_number) {
        this.Cerificate_license_number = Cerificate_license_number;
    }

    public String getVehicle_identifiers() {
        return vehicle_identifiers;
    }

    public void setVehicle_identifiers(String vehicle_identifiers) {
        this.vehicle_identifiers = vehicle_identifiers;
    }

    public String getDevice_identifiers() {
        return Device_identifiers;
    }

    public void setDevice_identifiers(String Device_identifiers) {
        this.Device_identifiers = Device_identifiers;
    }

    public String getLinkedIn() {
        return LinkedIn;
    }

    public void setLinkedIn(String LinkedIn) {
        this.LinkedIn = LinkedIn;
    }

    public String getInternet_protocol_addresses() {
        return Internet_protocol_addresses;
    }

    public void setInternet_protocol_addresses(String Internet_protocol_addresses) {
        this.Internet_protocol_addresses = Internet_protocol_addresses;
    }

    public String getBiometric_identifiers() {
        return Biometric_identifiers;
    }

    public void setBiometric_identifiers(String Biometric_identifiers) {
        this.Biometric_identifiers = Biometric_identifiers;
    }

    public String getFull_face_photos() {
        return Full_face_photos;
    }

    public void setFull_face_photos(String Full_face_photos) {
        this.Full_face_photos = Full_face_photos;
    }

    public String getAny_unique_identifying_number() {
        return Any_unique_identifying_number;
    }

    public void setAny_unique_identifying_number(String Any_unique_identifying_number) {
        this.Any_unique_identifying_number = Any_unique_identifying_number;
    }
    private String vehicle_identifiers;
    private String Device_identifiers;
    private String LinkedIn;
    private String Internet_protocol_addresses;
    private String Biometric_identifiers;
    private String Full_face_photos;
    private String Any_unique_identifying_number;

    public void setDescr(String text) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
